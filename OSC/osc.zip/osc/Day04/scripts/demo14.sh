#!/bin/bash

echo "Pos params : $*"
echo "Count : $#"

echo "Script name : $0"
echo "1st param : $1"
echo "2nd param : $2"
echo "3rd param : $3"


























