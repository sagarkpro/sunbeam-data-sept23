#!/bin/bash

arr=(10 20 30 40 50)

echo "arr : ${arr[*]}"
echo "arr : ${#arr[*]}"


echo "arr[0] : ${arr[0]}"
echo "arr[1] : ${arr[1]}"


























