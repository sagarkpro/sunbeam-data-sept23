#!/bin/bash


# Variable declarartion
#	<variable name>=<value>

# Variable usage
#	$<variable name>

num=10
pi=3.142
str=sunbeam

echo $num
echo $pi
echo $str

echo "num = $num"
echo "pi = $pi"
echo "str = $str"
























