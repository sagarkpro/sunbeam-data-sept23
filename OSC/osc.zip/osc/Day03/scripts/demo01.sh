#!/bin/bash

# Shebang line - to identify for which shell this script is written

echo "This is my first script"
echo "Hello DAC"


# This is comment

# Step 1 : create demo01.sh file
# Step 2 : execute the script
	# 1 : bash demo01.sh

	# 2 : chmod +x demo01.sh
	#	: ./demo01.sh
