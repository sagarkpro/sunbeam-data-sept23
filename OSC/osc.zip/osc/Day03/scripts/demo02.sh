#!/bin/bash

echo -n "Today's date : " 
date

echo "Current month calender : "
cal

echo -n "Operating system : "
uname
