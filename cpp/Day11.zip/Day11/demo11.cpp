#include <iostream>
using namespace std;

int main()
{
    int num1 = 10;
    if (double newsal; num1 == 10)
        return 0;
}