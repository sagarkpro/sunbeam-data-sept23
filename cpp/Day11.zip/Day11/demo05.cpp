#include <iostream>
using namespace std;

int main()
{
    int num1 = 24;
    cout << "hello" << endl;
    cout << "world" << endl;
    cout << "hex = " << hex << num1 << endl;
    cout << "oct = " << oct << num1 << endl;
    cout << "dec = " << dec << num1 << endl;
    return 0;
}