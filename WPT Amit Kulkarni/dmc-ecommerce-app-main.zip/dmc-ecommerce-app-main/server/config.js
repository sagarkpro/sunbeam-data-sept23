module.exports = {
  secrete: 'J7F8PwvXIAV7aqXyN3fb9MnZkiaeadEc',
}
