//
//  OrdersViewController.swift
//  MyStore
//
//  Created by Amit Kulkarni on 20/01/24.
//

import UIKit

class OrdersViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
