//
//  ChangePasswordViewController.swift
//  MyStore
//
//  Created by Amit Kulkarni on 20/01/24.
//

import UIKit

class ChangePasswordViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
