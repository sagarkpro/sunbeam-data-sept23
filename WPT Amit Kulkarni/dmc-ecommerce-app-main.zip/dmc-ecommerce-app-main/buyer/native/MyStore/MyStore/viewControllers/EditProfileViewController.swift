//
//  EditProfileViewController.swift
//  MyStore
//
//  Created by Amit Kulkarni on 20/01/24.
//

import UIKit

class EditProfileViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
