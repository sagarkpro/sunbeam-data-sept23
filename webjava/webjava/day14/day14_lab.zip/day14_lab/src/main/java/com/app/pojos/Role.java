package com.app.pojos;

public enum Role {
	EMP, MANAGER
}
