package com.app.entities;

public enum ProjectStatus {
	LAUNCHED, COMPLETED, CANCELLED
}
