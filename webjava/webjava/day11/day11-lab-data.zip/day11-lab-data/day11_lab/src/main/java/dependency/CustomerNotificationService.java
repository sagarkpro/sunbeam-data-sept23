package dependency;

public interface CustomerNotificationService {
	 void alertCustomer(String mesg);
}
