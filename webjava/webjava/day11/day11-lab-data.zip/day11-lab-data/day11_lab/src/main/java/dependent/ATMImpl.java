package dependent;

import dependency.CustomerNotificationService;
import dependency.Transport;

public class ATMImpl implements ATM {
	private double cash;
	private Transport myTransport;
	private CustomerNotificationService notificationService;

	public ATMImpl(double cash1234) {
		this.cash = cash1234;
		System.out.println(
				"in cnstr of " + getClass().getName() + " " + cash + " " + myTransport + " " + notificationService);
	}

	@Override
	public void deposit(double amt) {
		System.out.println("depositing " + amt);
		byte[] data = ("depositing " + amt).getBytes();
		myTransport.informBank(data);// depnt obj using depcy
		notificationService.alertCustomer("You have deposited  " + amt);


	}

	@Override
	public void withdraw(double amt) {
		System.out.println("withdrawing " + amt);
		byte[] data = ("withdrawing " + amt).getBytes();
		myTransport.informBank(data);//using transport layer
		notificationService.alertCustomer("You have withdrawn  " + amt);
	}
	// setter based D.I for transport layer
	public void setMyTransport(Transport myTransport) {
		this.myTransport = myTransport;
		System.out.println("in setter : transport");
	}
	//setter based D.I for customer notofication
	public void setNotificationService(CustomerNotificationService notificationService) {
		this.notificationService = notificationService;
		System.out.println("in setter : cust notification");
	}

	// init method
	public void myInit() {
		System.out.println("in init " + myTransport);
	}

	

	// destroy method
	public void myDestroy() {
		System.out.println("in destroy " + myTransport);
	}

}
