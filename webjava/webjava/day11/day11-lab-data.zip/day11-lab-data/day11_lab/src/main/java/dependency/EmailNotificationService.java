package dependency;

public class EmailNotificationService implements CustomerNotificationService {
	public EmailNotificationService() {
		System.out.println("in ctor of " + getClass());
	}

	@Override
	public void alertCustomer(String mesg) {
		System.out.println("Hello , Customer ! , alerting using " + getClass() + " mesg : " + mesg);

	}

}
