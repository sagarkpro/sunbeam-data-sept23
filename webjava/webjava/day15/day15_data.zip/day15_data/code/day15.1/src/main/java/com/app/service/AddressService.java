package com.app.service;

import com.app.pojos.Address;

public interface AddressService {

	String assignEmpAddress(Long empId, Address adr);

}
