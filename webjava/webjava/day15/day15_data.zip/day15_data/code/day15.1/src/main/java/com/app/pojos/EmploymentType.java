package com.app.pojos;

public enum EmploymentType {
	FULL_TIME, PART_TIME, CONTRACT
}
