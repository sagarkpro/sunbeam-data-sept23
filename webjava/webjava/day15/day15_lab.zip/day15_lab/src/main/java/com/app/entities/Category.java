package com.app.entities;

public enum Category {
	BOOKS, MAGAZINES, CLOTHES, FOOTWEAR
}
